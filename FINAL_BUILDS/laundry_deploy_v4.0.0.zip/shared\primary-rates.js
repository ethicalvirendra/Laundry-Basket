const PRIMARY_RATE_VERSION = '2026-05-30-primary-rate-card';

const PRIMARY_RATE_ROWS = [
    ['Men', 'SHIRT', '50-100', '20', '10', '8'],
    ['Men', 'T-SHIRT', '50-100', '20', '10', '8'],
    ['Men', 'TROUSER', '50-100', '20', '10', '8'],
    ['Men', 'JEANS/TROUSER HEAVY', '50-100', '20', '15', '12'],
    ['Men', 'KURTA', '50-100', '20', '10', '8'],
    ['Men', 'COAT/BLAZER', '80-250', '', '70', '60'],
    ['Men', 'DHOTI', '100-200', '50', '25', '20'],
    ['Men', 'PAJAMA', '50-100', '20', '10', '8'],
    ['Men', 'SHERWANI', '200-250', '', '120', ''],
    ['Men', 'SHORTS', '40', '', '10', '8'],
    ['Men', 'SWEATER', '100-200', '60-100', '25', '20'],
    ['Men', 'LEATHER JACKET POLISH', '200-300', '', '', ''],
    ['Men', 'REXINE JACKET POLISH', '200-300', '', '', ''],
    ['Men', 'JACKET', '180-300', '', '', ''],
    ['Men', 'UNDERGARMENT', '30-50', '20', '10', '8'],
    ['Women', 'SALWAR/LEGGINGS', '50-100', '20', '10', '8'],
    ['Women', 'KURTA PLAIN', '50-100', '20-60', '10', '8'],
    ['Women', 'SUIT HEAVY', '150-500', '', '100-200', '80-150'],
    ['Women', 'SAREE', '180-500', '', '70-100', '50-100'],
    ['Women', 'LEHANGA HEAVY', '250-1000', '', '120-250', '100-200'],
    ['Women', 'DUPATTA FANCY', '50-100', '30', '20', '15'],
    ['Women', 'BLOUSE FANCY', '50-100', '', '15', '12'],
    ['Women', 'SKIRT', '80-150', '', '30', '25'],
    ['Women', 'JACKET DENIM', '100-200', '', '30', '25'],
    ['Women', 'SHAWL', '90-200', '', '30', '25'],
    ['House Item', 'BED SHEET SINGLE', '60', '25', '15', '12'],
    ['House Item', 'BED SHEET DOUBLE', '80', '30', '15', '12'],
    ['House Item', 'BLANKET SINGLE', '250-300', '', '', ''],
    ['House Item', 'BLANKET DOUBLE', '300-500', '', '', ''],
    ['House Item', 'QUILT COVER SINGLE', '80', '60', '20', '15'],
    ['House Item', 'QUILT COVER DOUBLE', '120', '80', '20', '15'],
    ['House Item', 'PILLOW', '100', '', '10', '10'],
    ['House Item', 'CUSHION', '50', '30', '10', '8'],
    ['House Item', 'CUSHION COVER', '30', '20', '', ''],
    ['House Item', 'HAND TOWEL', '20', '12', '', ''],
    ['House Item', 'TOWEL BIG', '40', '20', '', ''],
    ['House Item', 'CURTAINS', '80-160', '40-80', '30-60', ''],
    ['House Item', 'BATHROBE', '60-100', '40-80', '', ''],
    ['House Item', 'MAT', '40-60', '30', '', ''],
    ['House Item', 'TABLE MAT', '40-80', '30-50', '', ''],
    ['House Item', 'TABLE COVER', '40', '30-50', '15-25', ''],
    ['House Item', 'CARPET', '400-2000', '', '', ''],
    ['Shoes', 'SHOE', '250-500', '', '', ''],
];

const HOTEL_RATES = [
    ['Bed Sheet (Single)', '8'], ['Bed Sheet (Double / King)', '15'], ['Pillow Cover', '7'],
    ['Duvet Cover', '25'], ['Bed Cover', '25'], ['Runner', '8'], ['Frill', '15'],
    ['Bath Towel', '10'], ['Hand Towel', '10'], ['Face Towel', '8'], ['Bath Mat', '10'],
    ['Table Cloth', '10'], ['Cloth Napkin', '8'], ['Table Runner', '8'], ['Chair Cover', '15'],
    ['Chef Coat', '25'], ['Staff Uniform', '25'], ['Apron', '15'],
    ['Blanket (Single)', '150'], ['Blanket (Double)', '300'],
    ['Guest Laundry - Shirt', '20'], ['Guest Laundry - Pant', '20'], ['Guest Laundry - T-Shirt', '15'],
    ['Guest Laundry - Jeans', '20'], ['Guest Laundry - Shorts', '15'],
    ['Guest Laundry - Track Pant', '15'], ['Guest Laundry - Vest / Underwear', '15'],
    ['Guest Laundry - Handkerchief', '10'],
];

const WASH_ONLY_RATES = [
    ['Men', 'T Shirt', '30'], ['Men', 'Shirt', '40'], ['Men', 'Pants', '40'], ['Men', 'Jeans', '50'],
    ['Women', 'Top Plain', '30'], ['Women', 'Legging', '30'], ['Women', 'Kurta Plain', '40'], ['Women', 'Jeans', '50'],
];

const SHOE_CLEANING_RATES = [
    ['Canvas Shoes', '310'], ['Slippers', '310'], ['Sport Shoes', '310'], ['Sandals', '380'],
    ['Leather Shoes', '760'], ['Suede Leather Shoes', '760'], ['Ankle Length Boots', '990'],
    ['Mid Length Boots', '1270'], ['Knee Length Boots', '1600'],
];

function normalizeCategory(category) {
    const value = String(category || '').trim();
    if (/^mens$/i.test(value)) return 'Men';
    if (/^womens$/i.test(value)) return 'Women';
    if (/^house\s*hold$/i.test(value)) return 'House Item';
    if (/^household$/i.test(value)) return 'House Item';
    return value;
}

function normalizeItemKey(item) {
    return String(item || '')
        .trim()
        .toLowerCase()
        .replace(/\bleggines\b/g, 'leggings');
}

function lowestNumber(displayPrice) {
    const match = String(displayPrice || '').match(/\d+/);
    return match ? Number(match[0]) : 0;
}

function exactPriceItem(item, category, serviceType, displayPrice) {
    const priceText = String(displayPrice || '').trim();
    return {
        item,
        category: normalizeCategory(category),
        serviceType,
        price: lowestNumber(priceText),
        displayPrice: priceText,
        source: 'primary-rate-card',
        locked: true,
        updatedAt: PRIMARY_RATE_VERSION,
    };
}

function normalizeRate(rate) {
    const displayPrice = rate.displayPrice ?? rate.price;
    return {
        ...rate,
        item: rate.item,
        category: normalizeCategory(rate.category),
        serviceType: rate.serviceType,
        price: Number(rate.price ?? lowestNumber(displayPrice) ?? 0),
        displayPrice: displayPrice === undefined || displayPrice === null ? undefined : String(displayPrice),
    };
}

function rateKey(rate) {
    return [
        String(rate.serviceType || '').trim().toLowerCase(),
        normalizeCategory(rate.category).toLowerCase(),
        normalizeItemKey(rate.item),
    ].join('|');
}

const PRIMARY_RATES = [
    ...PRIMARY_RATE_ROWS.flatMap(([category, item, dry, wash, steam, iron]) => [
        dry && exactPriceItem(item, category, 'Dry Clean', dry),
        wash && exactPriceItem(item, category, 'Wash & Iron', wash),
        steam && exactPriceItem(item, category, 'Steam Iron', steam),
        iron && exactPriceItem(item, category, 'Iron', iron),
    ].filter(Boolean)),
    ...HOTEL_RATES.map(([item, price]) => exactPriceItem(item, 'Hotel', 'Hotel Linen', price)),
    ...WASH_ONLY_RATES.map(([category, item, price]) => exactPriceItem(item, category, 'Wash Only', price)),
    ...SHOE_CLEANING_RATES.map(([item, price]) => exactPriceItem(item, 'Shoes', 'Shoe Cleaning', price)),
];

function mergeRatesWithPrimary(existingRates = []) {
    const primaryByKey = new Map(PRIMARY_RATES.map(rate => [rateKey(rate), rate]));
    const merged = [];
    const mergedKeys = new Set();

    existingRates.forEach(rate => {
        const plainRate = typeof rate.toObject === 'function' ? rate.toObject() : rate;
        const normalized = normalizeRate(plainRate);
        const key = rateKey(normalized);
        if (mergedKeys.has(key)) return;
        const primaryRate = primaryByKey.get(key);
        const isAdminOverride = normalized.source === 'admin-rate-card' || normalized.locked === false;
        merged.push(primaryRate && !isAdminOverride ? primaryRate : normalized);
        mergedKeys.add(key);
    });

    PRIMARY_RATES.forEach(rate => {
        if (!mergedKeys.has(rateKey(rate))) {
            merged.push(rate);
            mergedKeys.add(rateKey(rate));
        }
    });

    return merged;
}

module.exports = {
    PRIMARY_RATE_VERSION,
    PRIMARY_RATE_ROWS,
    HOTEL_RATES,
    WASH_ONLY_RATES,
    SHOE_CLEANING_RATES,
    PRIMARY_RATES,
    exactPriceItem,
    mergeRatesWithPrimary,
    normalizeCategory,
    normalizeItemKey,
    rateKey,
};
